# 视频链路源码审计后：Mac mini 本地验证方案

> 本文只执行**审计后有必要的验证**，不把已完成的仓库静态审计重新交给 Codex。首轮完全离线、隔离、不下载视频、不调用真实 Provider、不变更生产库或当前服务。冻结仓库 SHA `57df74ab8761223f49acbc9a29a26d0aba2b0b08`。

## A. 运行前的风险门禁

1. 在本机**现有克隆**中执行 `git status --short` 与 `git rev-parse HEAD`，确认代码提交；不能因为当前分支更新而静默改用最新代码。无需手动 reset、stash、clean，也无需停止生产服务。
2. 脚本用 `git worktree add --detach` 在 `/tmp` 下创建隔离审计工作副本。所有 Python 测试的 `ZHIJIAN_DATA_DIR`、`ZHIJIAN_STORAGE_CONFIG` 指向独立临时根，`ENV=development`、`ZHIJIAN_SECRET_STORE=file`。CI/测试命令在副本上进行，绝不向 `/Volumes/D/...` 生产 data 根写入。
3. 不直接对正在由 FastAPI 提供的 `frontend/dist` 执行 `pnpm build`；隔离工作树单独构建。
4. 默认不运行 `zhijian-worker`、`zhijian-api`、`deploy/macos/manage.py restart`、`alembic upgrade`、真实 `/api/capture`，不通过已部署的 API 发起写请求；不读取/打印 Keychain 值。
5. 本地 `.venv` 必须已有 pytest/ruff/项目依赖。缺依赖时显示 **BLOCKED_ENVIRONMENT**；不要悄悄 pip 装到生产 venv。前端离线 pnpm cache 缺失也显示阻塞，不能把它误判为项目缺陷。

## B. 直接执行

将 `03_LOCAL_AUDIT_RUNNER.sh` 放在当前仓库外任意目录，运行：

```bash
bash /path/to/03_LOCAL_AUDIT_RUNNER.sh /path/to/do-not-litter
```

脚本只做：冻结 SHA → 隔离 Worktree → 迁移 head 只读检查 → 后端目标+全量测试 → Ruff → 既有云南离线回归 → 前端离线安装/测试/Lint/隔离构建；把结果写入 `/tmp/zhijian-video-audit-*/results/`。不直接运行真实下载/推理。可能需要较多本机计算资源；不影响生产库，但测试和构建仍会占用 CPU、磁盘和内存，建议非繁忙时执行。

如果报告“本地克隆缺少冻结 SHA”，可在确认网络和远端可信后手动执行 `git -C /path/to/do-not-litter fetch origin codex/mac-mini-implementation`（只更新 Git 对象和远端引用，不切换当前工作树），再重试；脚本不会自动 fetch。

若命令阻塞依赖，请记录 `BLOCKED_ENVIRONMENT` 和具体环境版本，不在生产项目上自动调整依赖。

## C. 四项最优先的“红灯负例”——需要本地新增隔离测试，不能因旧回归全绿而忽略

| ID | 文件/入口 | 输入 | 修复前的代码风险 | 通过标准 |
|---|---|---|---|---|
| NEG-01 | `video_support._insights_from_candidate` | Segment“门票100元”，候选 `highlights=["免费入园"]` | 不相关要点挂上合法引文 | 自动 SOURCE_FACT 为 0，或需要人工审核；正确票价保留 |
| NEG-02 | 字幕选择 | 首轨可读但短/时间错，次轨可读且完整 | 首轨先被选、被质量拒绝，直接 ASR | 选次轨且 ASR=0，审计两轨原因 |
| NEG-03 | `YouTubeAdapter` | 同语言 srv3 在 VTT 之前 | srv3 交给 VTT 解析器 | 正确选择 VTT 或正确解析 srv3，无误触 ASR |
| NEG-04 | 初次 vs Replay 截图 | 同一个非登录 `MediaDownloadError` | 首次 PARTIAL，续跑 FAILED | Job 终态语义、Note 可见性一致 |

这四项先由 Codex 在 `/tmp` 的副本里**只新增测试、不修复源码**确认红灯，提交 `REPRODUCED`/`NOT_REPRODUCED` 和完整堆栈（脱敏）。**如按契约确认后才实施修复**，避免“改造掩盖原始问题”。

## D. 完整业务矩阵（先离线，后真实）

### D1. 必跑离线安全路径

| 类别 | 场景 | 预期 |
|---|---|---|
| URL | B站标准/短链/分享话术、YouTube watch/short、多个不同链接 | 安全规范化；多 URL 要求明确选择；无外部网络 |
| 字幕 | 人工中文/AI 中文、轨道失败、轨道质量拒绝、错时间轴、VTT/srv3 | 优先有质量依据的轨道；不误选；源轨可审计 |
| ASR | Whisper/Qwen 分批对齐、时间码、空结果、超时、取消、回退 | 不污染旧 Transcript；无需真实 GPU 也可 Mock 路径 |
| 校对 | 同音地名/菜品、长视频拆分、越界 Segment ID、错误 JSON | 保留原文；覆盖率/拒绝/重试可审计 |
| Ground Map | 多核心段落、地区/景区/餐馆、reference only、不推荐地点、确切引文 | 无跨段误关联；不漏报、不凭空加点 |
| 地点事实 | 菜品/价格/等待/限制/季节/路线、否定约束 | 各字段有自己证据，负向观点不被改为正向 |
| POI | 同名跨省/原词错字/地图代表点/人工拒绝/重复 Provider ID/并发确认 | 高置信自动确认不跨域，低置信需要审核 |
| 地图路线 | 同名站、重复途经、不同季节同线路、Destination、用户 RouteDraft | 来源路线不冒充导航，地点绑定及用户数据保留 |
| Job | 429/503/超时/取消/Requeue/Replay/缓存过期/晚结果 | 不双写，不重复结算成功，不静默完成 |
| UI | 962/390px 地图/视频笔记/复核/路线/设置/失败提示 | 关键状态完整，操作/刷新不丢人工修正 |
| 导出删除 | TXT/旧 travel export/v2、Note 删除/来源保留、180天过期 | 可追溯/不泄密/引用一致 |

### D2. 真实验收另行明确授权，不能由默认脚本触发

建议每条“真实视频”都先冻结一个可公开或用户有权限的本地测试 fixture，记录：BVID/CID、Snapshot/Transcript 版本、手工标注的核心主题与每个地点、每条事实/时节的原句、作者路线原话、POI 预期、完整输出、usage/计费是否为 reported/estimated/unknown。不可把 71 个候选当成 71 个 POI Pin。

分层：

- T1 B站有人工字幕短视频（无需 ASR）。
- T2 B站无字幕、需要 ASR，覆盖口音/地名。
- T3 探店：多菜品、费用、作者“不推荐”、适合时段。
- T4 贵州 43 地点：复杂多核心、段落归属和长分包。
- **T5 云南 `BV16Yem6REyX`：P0_CRITICAL**，路线/季节/地区背景/路段限制，人工裁定 18 字面未匹配与 39 额外。
- T6 同名异省/地区 vs 景区内部地点、跨来源重复确认。
- T7 YouTube 手动 VTT、srv3、无字幕（视来源可访问性）。
- T8 异常：真实 429/503/模型超时/取消/Fallback/缓存/恢复，必须隔离防止高代价重复调用。

先只读已有结果并标注，再执行新的真实模型请求。真实操作前应另外确定模型额度、请求次数上限、样本授权和数据备份；禁止无授权重跑生产历史任务。

## E. 交付形式与分级判定

Codex 在本地只需向你输出：`AUDIT_LOCAL_RESULT.md`、`repro/NEG-01..04.json`（不含密钥）、`pytest-target.log`、`pytest-full.log`、`frontend.log`、`yunnan-offline-report.json`、`environment.json`。必须分别标识：

- `PASS_OFFLINE`：实际运行且通过；
- `REPRODUCED_CODE_DEFECT`：有可重复的失败与最小输入；
- `NOT_REPRODUCED`：已尝试但未触发，不据此宣称“绝无缺陷”；
- `BLOCKED_ENVIRONMENT`：环境/依赖阻塞；
- `NOT_RUN_REAL_E2E`：没有真实 Provider/高德/视频授权；
- `PRODUCTION_NOT_VERIFIED`：未读当前生产状态。

**修复流程**：先冻结负例与基线，再 P0/P1 小批修复，每包目标测试、一次全量回归；对语义改动强制 Golden Review；修复前不要清空已有 Review/历史/墓碑，不要在此任务内修改 LocalAiMux。
