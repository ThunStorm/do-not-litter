# 至简 Phase 1 视频链接业务：源码审计报告

审计日期：2026-10-28  | 仓库：`ThunStorm/do-not-litter`  | 分支：`codex/mac-mini-implementation`  | **冻结 SHA：`57df74ab8761223f49acbc9a29a26d0aba2b0b08`**

## 0. 方法、范围与证据等级

本次直接读取 GitHub 仓库中当前 SHA 的源码、测试、工程配置和当前交接/验收材料，覆盖：视频 URL 投递 → Bilibili/YouTube Resolver → 字幕/ASR → 校对 → Grounded Map → 笔记 → POI/区域 → 地图/作者路线 → 截图 → 保存/导出 → 任务续跑/资源/模型网关。检查也涉及所有影响这一链路的跨层契约，但**不纳入招聘、非视频网页、PDF/Office 输入开发**。

**证据等级**：`C` = 源码确定的行为或明确的契约缺口；`R` = 源码结构支持的条件性风险，需要隔离复现才能证明用户影响；`G` = 缺少真实业务质量或部署门禁证据（不称作代码 Bug）。`P0` 需优先处理（可信事实/错误业务状态）；`P1` 下一修复批次；`P2` 可排期治理。

**重要边界**：本报告没有在用户 Mac mini 上运行 pytest、Node 构建、实际视频下载、真实模型/高德；旧文档的 703 后端/59 前端通过是**2026-10-28 的仓库记录**，不等于本轮重新实测或当前线上已通过；云南报告中的真实模型样本为此前授权的小样，未有独立的全语义金标。

直接查看冻结提交：[GitHub 树](https://github.com/ThunStorm/do-not-litter/tree/57df74ab8761223f49acbc9a29a26d0aba2b0b08)。所有下面的源码链接使用不可漂移的 SHA。

## 1. 执行摘要

- 工程上的优势：有独立 Worker/SQLite WAL/lease/fence、JobStepArtifact 续跑、视频版本化 Transcript、source/evidence、LLM 请求边界与重试/预算、缓存、POI 保守自动确认与人工 revision、地图与个人 RouteDraft 隔离。不是空壳项目，不宜推倒重写。
- **核心风险集中在“最后一公里可信投影”**：Ground Map 基础引用可能是逐字真实的，但某个展示字段/要点并不一定被该原句支持；路线站点、时间段在投影/绑定时也应与具体 Claim/原文一一关联。仅验证 `quote` 出现在视频中，**不能等同于**该 `value_text` 就是真实、正确的结论。
- **另一个薄弱环节是处理与 Replay 的行为等价性**：已确认截图下载异常在首次处理与续跑的分支不同；部分步骤缺失缓存文件时，状态可能不准确。
- 存在“源码构建/离线规则通过，但真实视频提取质量仍未验”的边界。2026-10-28 云南报告给出了 53 个字面重合、39 个额外、18 个未匹配的**未裁定差异**，不是直接语义 FP/FN；其余场景还需独立标注。

## 2. 逐项发现与修复建议

### V01｜P0｜C｜视频要点可在缺少事实支持时被保存为 SOURCE_FACT

**证据**：[video_support.py L3294–L3380](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/video_support.py#L3294-L3380) 的 `_insights_from_candidate().add()`：若要点值在任何合法 Segment 中都找不到，也未给出证据 ID，会使用 `ids = ids or list(segment_ids)`；`source_quote` 也可以直接取模型给出的文本；随后的 `materialize_place_insights`（[L3383–L3410](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/video_support.py#L3383-L3410)）按 metadata 将其物化为 `SOURCE_FACT`/`SOURCE_OPINION`，未再次校验 `value_text` 是否被 quote 支持。

**最小反例**：实体本身有真实句子“甲景区门票100元”，模型却输出 `highlights=["免费入园"]`。实体证据和 Segment ID 合法，但 `HIGHLIGHT/免费入园` 可能被挂上“门票100元”的原句，构成“有引文但引文不支持事实”。这不等同于模型一定会这样输出，而是**代码门禁允许该矛盾进入业务数据**。

**修复**：将 “字段事实” 与“实体存在”分开验证；为每个要点、菜品、价格、月份、提醒建立字段级 Evidence（`segment_ids`、完整原句、支持状态）；对日期/价格/否定作确定性一致性校验；语义概括无法确定支持时置 `NEEDS_REVIEW`，不得宣称 SOURCE_FACT。避免简单“摘要必须逐字在原文里”而误伤合法改写；采用可审计的严格规则/小范围模型核对。

**回归**：真实句子“收费100元”，强制输入相矛盾的“免费”；确认最终不进入高置信要点；正例“票价约100元”的合规概述仍通过。

### V02｜P1｜C｜字幕抓取成功但质量未过时不再尝试备用轨道

**证据**：[bilibili.py L291–L303](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/resolvers/video/bilibili.py#L291-L303) `first_usable_subtitle` 收到第一个 `fetch(track)` 正常返回就立即结束；[video_pipeline.py L882–L980](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/video_pipeline.py#L882-L980) 在此之后才进行 `_subtitle_decision`，若质量不合格直接下载音频 ASR。

**触发**：首轨能成功解析但覆盖率不足/时间轴不合理，下一轨可能有完整中文字幕。造成不必要的音频下载、ASR 成本以及可能的识别质量下降。

**修复**：把 `fetch → validate → accept/continue` 合并为按优先级遍历所有候选轨道的单一决策循环；对 `VIDEO_LOGIN_REQUIRED` 保留明确人工处理；审计每轨“下载成功但质量拒绝”与 “下载失败”。

**回归**：A 轨合法但短，B 轨完整，应选 B，ASR 调用 0；A/B 均拒才走 ASR。

### V03｜P1｜C｜YouTube srv3 字幕的选择与解析格式不一致

**证据**：[youtube.py L107–L126](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/resolvers/video/youtube.py#L107-L126) 从 yt-dlp 提取第一条 `ext in {vtt,srv3}` 的字幕；[L84–L95](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/resolvers/video/youtube.py#L84-L95) 统一传 `_parse_vtt`；[L129–L146](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/resolvers/video/youtube.py#L129-L146) 仅识别 `-->` VTT 时间码，未解析 srv3 XML 时间码。

**触发**：同一语言的第一份字幕是 srv3，即使 yt-dlp 同时提供 vtt，代码也不会再找 vtt，最终可能以 `VIDEO_SUBTITLE_INVALID` 触发 ASR。

**修复**：优先选 VTT；srv3 要么实现合法解析、时间码和实体解码，要么暂不选为候选。两种格式用独立 fixture 测试。

### V04｜P1｜C｜截图下载失败：首次处理部分成功，续跑可能整体失败

**证据**：[video_pipeline.py L1146–L1187](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/video_pipeline.py#L1146-L1187) 首次处理非登录 `MediaDownloadError` 转为 `screenshot_error`、标记子步骤失败并继续交付文字；[L1661–L1695](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/video_pipeline.py#L1661-L1695) Replay 对同类异常直接 `raise`，在上层通常变成 Job `FAILED`。

**影响**：本来可以获得的 Note 在“重新试一次截图”时给出比初次更差的整体状态，严重影响续跑可靠性。

**修复**：抽取统一 screenshot enrichment 错误策略，正常处理与 Replay 共用 `partial / needs_user / fail` 分类；继承已有成功文本/地点物化，不让可选截图失败覆盖核心结果。

**回归**：同一个合成 `MediaDownloadError` 分别进入两条路径，期望同样的 Job 级语义与内容可见性。

### V05｜P1｜C｜截图 Replay 找不到缓存时有机会以“完成”掩盖缺图

**证据**：[video_pipeline.py L1695–L1724](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/video_pipeline.py#L1695-L1724)：从 `EXTRACT_SCREENSHOTS` 步骤恢复，若视频缓存文件没找到，调用 `_skip_step`，但没有填充 `screenshot_error`；[L1742–L1745](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/video_pipeline.py#L1742-L1745) 仅以 `unresolved or screenshot_error` 判断 `PARTIAL_SUCCESS`。

**边界**：正常公开入口 `replay_options` 对某些缺失 Artifact 会提前拒绝，故**并非所有 UI 续跑都会触发**。但执行器分支本身缺少防御性失败/部分成功标记，需隔离测试其可达性。归类为已确认的状态分支缺口，用户可见影响待实测。

**修复**：存在有效计划但素材不可用时明确记录 `SCREENSHOT_ARTIFACT_MISSING`，退化为部分成功或暂停重取，不得清零错误标志。

### V06｜P1｜C｜作者路线站点只按名称绑定，不绑定该路线的原文片段

**证据**：[route_guides.py L195–L218](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/route_guides.py#L195-L218)：`stop["raw_name"] in {m.name,m.raw_name}` 与当前 Note Version 的全部已确认 Mention 比较；没有检查站点与路线的 `content_unit_id`、`segment_ids`、地域上下文、Source Claim 的归属。某一同名地点在别处已确认、路线中的同名站点属于另一地域且尚未确认时，可能把路线站点标成已确认并进一步允许复制。

**修复**：RouteGuide Stop 的身份应有 `(route_claim_id, mention_id, segment_ids, scope/行政链)`；必须唯一匹配同一相关句/地理域内的 Mention，不能仅靠文本名。无法确认则 `NEEDS_REVIEW`，复制前逐站复核。

**回归**：视频中“湖北东湖”和另一地区“东湖”，只确认前者；后者路线停靠站不得借用确认状态。

### V07｜P1｜R｜作者路线读取可能与生成笔记时的 GroundedMap 版本脱钩

**证据**：[route_guides.py L173–L201](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/route_guides.py#L173-L201) 读取全部 Artifact，并选择“同 video asset、同 transcript_version 最新创建”的 Artifact；[db/models.py L355–L371](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/db/models.py#L355-L371) 的 `AINoteVersion` 不存 `grounded_map_artifact_id`；GroundedMap 同一 Transcript 可随 Prompt/选项变化生成不同 Artifact。

**影响条件**：同一 Transcript 上发生 Ground Map 重新生成而旧 Note Version 仍为当前版本，作者路线 GET 可能切换为新的 Artifact，使笔记与路线来源事实不再严格一致。

**修复**：生成 Note 时冻结关联 `artifact_id/semantic_hash`，读取路线必须按精确身份绑定。迁移方案应考虑旧 Note 的只读回退与 Ambiguous 标记，不自动回填生产。

### V08｜P1｜C｜路线去重键忽略时节/限制/原文证据

**证据**：[route_guides.py L128–L153](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/route_guides.py#L128-L153)：去重只用 `(mode, stops, road, subject-if-no-stops)`；`conditions`、`evidence`、`sequence_kind` 不在键中，第二条同站序但不同注意事项或作者观点的路线对象被跳过。

**影响**：例如同一个 A→B→C 路线先介绍丰水期注意事项、后介绍冬季道路限制。模型能产出两条有效路线时，后者可能直接丢失。与“不漏报”目标冲突。

**修复**：区分“同一条路线的多个来源事实合并”与“重复路线对象删除”；路线身份聚合时 `conditions`、原句与日期做并集，并保留多条证据，不盲目丢弃第二条。

### V09｜P2｜C｜笔记列表无分页与查询总量保护

**证据**：[api/video_notes.py L143–L169](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/api/video_notes.py#L143-L169)：无搜索时 `db.execute(statement).all()` 加全部 `_note_view()`；当前未见列表 limit/cursor，`_note_view` 还需要 Mention 等派生读取。对象积累多后 API 及手机响应可能变慢。

**修复**：增加兼容的分页接口或 cursor（默认合理上限）、批量统计代替逐 Note 派生查询；保留当前 UI 兼容路径及搜索排序契约。用 100/1,000/10,000 Note 的隔离库测 SQL 数/请求 P95/响应体积。

### V10｜P2｜C｜路线上重复地名的顺序校验只取首次出现位置

**证据**：[route_guides.py L49–L58](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/route_guides.py#L49-L58)：每个站点用 `normalized_quote.index(normalized_stop)`，只取首次出现。若原句提到同名地点多次且第二次才属于路线的有效行程，可能错误拒绝或错误接受次序。此为确定的算法约束，不等于当前云南用例会触发。

**修复**：按句法/明确有序站点区间绑定单调递增 offset；对重复名称与回环另定义规则；位置模糊保留 `NEEDS_REVIEW`。

### V11｜P2｜R｜转写 180 天后派生原句仍可保留，需明确产品隐私契约

**证据**：[transcript_retention.py L17–L65](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/services/transcript_retention.py#L17-L65) 擦除 Transcript/Segment/Evidence.quote；但 [GroundedMapArtifact](https://github.com/ThunStorm/do-not-litter/blob/57df74ab8761223f49acbc9a29a26d0aba2b0b08/backend/src/zhijian/db/models.py#L312-L341)、PlaceMention.quote、PlaceInsightItem.source_quote、RouteGuide JSON、Note 仍可能保留摘录。项目规格允许衍生笔记继续保留，因此**不能断言这是数据泄露 Bug**；需验证“清理完整转写”是否被 UI/导出误解释为“清理所有原句”，及是否可能重组出全文。

**修复**：列明 RAW、CORRECTED、Evidence excerpt、Note、RouteGuide、FTS 的保留规则；对用户透明；如需全文不可重构，另建审计及清除策略，不破坏永久笔记证据的产品意图。

### V12｜P2｜R｜视频/地点/路线核心模块体量大、兼容分支多，回归耦合风险高

**证据**：`video_support.py` 4863 行、`video_pipeline.py` 1782 行、`api/router.py` 5169 行（本次源码读取长度）；其中重复生成/Replay、POI/时间/推荐存在多处事务边界与状态处理。体量本身**不是功能缺陷**。

**建议**：先锁定 API、错误码、来源/evidence、Stage/Job/Artifact 的契约测试，再以小模块拆分 `subtitle-selection`、`insight-evidence-validation`、`screenshot-enrichment`、`route-binding`；不要大范围一次性重构。

## 3. 业务设计符合性

| 能力 | 源码结论 | 还缺的独立验收 |
|---|---|---|
| B 站链接/短链接/分享话术 | 有输入规范化、受限 Resolver、登录及字幕降级路径；并非单一 HTTP 抓网页 | 最新平台真实 412/登录失效/非登录样本，多个字幕轨质量切换 |
| YouTube 链接 | 有适配器，进入共同视频流程；有 srv3/VTT 格式缺口 | 真正可访问视频、VTT、srv3、缺字幕和地区受限 |
| ASR/校对 | Whisper.cpp、Qwen3-ASR、分块、校对/对齐/调用预算已落地 | 方言/地名/快语速字准率、异常重试/超时实机 |
| Ground Map/Note | Evidence/Segment/实体/单元/缓存/版本存在，已针对单例做改善 | **语义事实支持率、多区域实体召回、核心内容/附属地点分组** |
| POI 匹配 | AUTO_STRONG、人工 Review、拒绝墓碑及地区门禁、Destination 代表点已有实现 | 同名跨省/内部景点与主景区、真实高德 QPS/TopK/错确认 |
| 旅行时节/路况 | 逐 mention 时间和活动差异、背景不加权，有近期整改 | 标注“谁/哪段路/何时/何种活动”；作者说法 vs 实时路况 |
| 作者路线 | 非导航对象、明确站序、原词和证据校验、独立 RouteDraft | 名称绑定正确率、条件合并、同一 Note/Artifact 版本一致性 |
| Screenshot/阅读 | 有截帧、质量过滤、封面/手机读图 | Replay 错误等价、失败不丢核心结果、PC/Mobile 真机 |
| 数据/任务 | Source/Transcript/Note/Place 分层、SQLite WAL、Worker、cancel/fence | crash/restart/分步续跑/外置卷丢失/数据迁移恢复 |

## 4. 当前真正的质量门禁（G，不计源码 Bug 数）

1. **完整视频 Golden 尚未人工验收**。仓库 2026-10-28 云南报告：真实模型输出 104 实体/76 Claim，经解析最终 102 候选、13 待核路线；71 参考候选字面 TP53/extra39/FN18，字面 precision 0.5761、recall 0.7465；由于别名、层级及背景差异，不能称为语义准确率。必须逐条裁定 TP/FP/FN、scope/activity/order、关键季节与负向建议。
2. **实机 5 模式 + 真实上游故障覆盖不足**。旧 AI Gateway 报告明确 `production_proven=false`，需要 LOCAL_ONLY/REMOTE_ONLY/LOCAL_FIRST/REMOTE_FIRST/AUTO、fallback、429/503/timeout、取消、缓存和模型实际释放。先离线再授权运行；不可因本地 Mock 通过而授生产 PASS。
3. **正式生产部署证明只取既有采样时间**。2026-10-28 14:34 交接有 API/Worker/SQLite 完整性记录，但本次没有重新连接生产，不断言现在服务健康/当前任务数/真实 Key。
4. **没有 `.github/workflows/` 持续集成工作流**（基于冻结 SHA 的 Git Tree）；仓库自述已执行 703/59 项全量自动验证，但 PR/提交缺独立持续质量门禁。对于个人 Mac mini 项目，可先实现本地一键静态回归，不必强制引入重型 CI。

## 5. 优先级决策与整改顺序

- **第一修复批 P0/P1**：V01 字段级 Evidence → V02/V03 字幕轨选择与格式 → V04/V05 首次/Replay 一致性 → V06 路线站点身份 → V08 路线条件合并。
- **第二修复批 P1/P2**：V07 冻结 Artifact 身份 → V10 重名行程顺序 → V09 分页与批量聚合；V11 明确保留边界。
- **验收 G**：必须独立冻结多类型视频金标，比较已保存基线与变更候选的实体、段落、时节、路线、POI 和成本，禁止仅在最终结果“看着不错”时宣告通过。

本报告不执行修复、不提交、不推送、不部署、不运行真实模型或写高德确认。后续 Mac 本地操作见 `02_LOCAL_VALIDATION_PLAN.md` 与 `03_LOCAL_AUDIT_RUNNER.sh`。
