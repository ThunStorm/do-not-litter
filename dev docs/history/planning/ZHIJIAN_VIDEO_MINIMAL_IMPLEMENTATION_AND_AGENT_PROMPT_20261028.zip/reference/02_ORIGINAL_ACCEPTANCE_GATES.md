# 视频链路独立业务质量验收门禁（建议值，非仓库现有实测）

以下阈值是**本次审计提出的建议发布门槛**，并非已完成的测量值。应先在至少 6 类固定视频上建立人工独立注释（类型、原词、别名、地域、时间码、主题单元、证据、路段活动、路线站序），冻结 baseline 与 candidate 两个相同输入环境，再做比较。首次采用阈值前应获得产品侧认可。

| 维度 | 建议验收方式 | 阻断条件 |
|---|---|---|
| 不漏报 | 按 `视频 × content_unit × entity` 统计 TP/FN，允许复核态的正确候选 | 核心被推荐地点在输入中有清楚直接证据却完全缺失；Candidate 的人工核对召回低于 Baseline |
| 不多报 | 区分 PLACE/AREA/LINEAR/GENERIC/REFERENCE；候选不等于地图 Pin | 原文未出现或未被支持的实体误自动确认上图；新增高严重度幻觉 |
| 地点定位 | 同名跨省、内部景点/景区/行政中心 | **错误自动 POI 确认 0**（黄金样本）；疑义应进 Review |
| 字段事实 | 菜品、费用、时间、作者态度、路况和季节逐字段指向事实支持的引文 | unsupported value 被标 `SOURCE_FACT` 或否定被变肯定 |
| 季节/用途 | 时间范围/跨年/月旬、景观最佳期、活动禁止、道路临时限制拆分核对 | 封路/禁止骑马等被泛化为整个地区不可游，或天气最佳期被伪装为道路可通行 |
| 路线 | `mode + source + stop order + scope + conditions` 校验 | 站序误排、跨地域借用 POI、把作者路线标成真实导航、不同限制条件被吞掉 |
| 证据 | Snapshot/Transcript/Segment/Note Version 连接及 quote 原文/支持性 | 跨来源串证据，历史人改丢失，已拒绝地点被复活 |
| 任务恢复 | 同输入同报错，首次/Replay/强制生成/缓存命中对照 | 核心结果被可选截图失败覆盖、晚结果污染新 Job、取消仍有新的外部调用 |
| 性能 Token | 区分模型 reported、估算、未知；记录输入输出 Token、wall time、外部调用数 | 相同质量下降却只按耗时缩短判 PASS，或把未知 usage 写成 0 |
| Mac 实机 | Provider、Qwen/Whisper、AMap、浏览器跨设备 | 未采集实测就宣称生产门禁通过 |

## 样本分层

- `FOOD_001`：多个餐馆、推荐菜和人均价格、相反态度、同名品牌；来源 `T-001` 厦门探店。
- `MULTI_001`：多地区、多核心与大于 40 个明确地点；来源 `T-002` 贵州 43 景点。
- `YUNNAN_001`：`BV16Yem6REyX`，**P0_CRITICAL**。保留既有 71 参考候选/11 路线/29 条离线断言作为 seed，人工复核额外与未匹配并形成真正语义 GT。
- `ASR_001`：无字幕、同音名词、语速快与时间码；比较 Whisper / Qwen 及校对后的结果。
- `BILI_SUB_001`：首轨质量不合格、次轨有效，或全部不合格触发 ASR；固定 Mock 不访问 B站。
- `YOUTUBE_001`：VTT + srv3 + 无字幕；固定响应 Mock，真实网络作为另行授权项。
- `GEO_001`：同名异省、AREA/景区内部、REFERENCE、不推荐地点、人工拒绝。
- `REPLAY_001`：首次/续跑截图非登录失败、缓存到期、429/503/timeout、取消与 late result。

## 结果报告字段

`sample_id, source_kind, transcript_version, note_version, grounded_map_artifact_id, baseline_sha, candidate_sha, expected_entities, predicted_entities, TP, FP, FN, unresolved, review, wrong_auto_confirmations, unsupported_source_facts, wrong_scope, wrong_activity, wrong_route_order, reported_input_tokens, reported_output_tokens, estimated_tokens, unknown_usage_count, external_calls, wall_seconds, examiner, evidence_refs`。

执行顺序：离线负例先红灯，修复后变绿；再人工冻结 Gold；最后在**明确授权的隔离环境**按预算运行真实视频。只提供字面集合比较不得填语义精确率/召回率数字；未人工裁定用 `null` 而非 0。
