# 至简视频链路：克制优化实施包（Agent 直执行版）

**冻结基线**：`ThunStorm/do-not-litter` / `codex/mac-mini-implementation` / `57df74ab8761223f49acbc9a29a26d0aba2b0b08`。文档日期 2026-10-28。

本包**不是一轮大重构**，也不是让 Agent 重新审计仓库；静态审计已完成。目的是基于真实源码缺陷执行小批修复，重点保护事实可信度、字幕降级成本、任务续跑可靠性和作者路线正确性。

## 开始顺序

1. **直接复制 `06_AGENT_EXECUTION_PROMPT.md` 全文给本地 Agent**。Agent 必须先读取本 README 和 `01_SCOPE_AND_CHANGE_POLICY.md`。
2. 按 `02_IMPLEMENTATION_WORK_PACKAGES.md` 的工作包 **WP0 → WP1 → WP2 → WP3 → WP4（条件性）** 逐批实施，若发现已被最新提交修复，应跳过而不是重复开发。
3. `03_AI_COST_AND_COMPLEXITY_GATES.md` 为硬门禁；`04_TEST_AND_LOCAL_VALIDATION.md` 为验证流程；`05_ACCEPTANCE_AND_HANDOFF.md` 为交付标准。
4. `reference/01_ORIGINAL_CODE_AUDIT.md` 保存完整初始静态审计证据；`reference/02_ORIGINAL_ACCEPTANCE_GATES.md` 是业务质量门禁；`scripts/01_OFFLINE_BASELINE_RUNNER.sh` 是只读离线基线脚本，**不是修复脚本**。

## 权限边界

本包授权的是**代码修复、隔离测试、报告**，不自动授权真实视频/LLM/高德调用、改生产库、部署、迁移、全历史重处理、提交和推送。严格遵循仓库 `AGENTS.md` 的更严格规则；若 Agent 运行环境另有用户授权边界，以更严格边界为准。

## 修复和延期概况

| 类别 | 处理 | 说明 |
|---|---|---|
| V01 | WP1 必做 | 要点级 Evidence，禁止无依据的 SOURCE_FACT；**新增真实 LLM 调用=0** |
| V02、V03 | WP2 必做 | 字幕质量迭代，YouTube 仅用受支持 VTT；默认无新增 ASR/LLM |
| V04、V05 | WP3 必做/验证 | 初次与 Replay 的截图降级一致性；V05 先证入口可达 |
| V06、V08 | WP4 必做 | 路线站点范围绑定、不同限制事实保留 |
| V07 | WP4 条件性 | 必须先复现 Artifact 错绑，禁止直接迁移 |
| V09、V10、V11、V12 | **本批不改** | 分页、重复地名边界、保留策略、模块大小；仅测试或列入后续 Backlog |

## 文件表

- `01_SCOPE_AND_CHANGE_POLICY.md`：架构约束、禁止野蛮扩张
- `02_IMPLEMENTATION_WORK_PACKAGES.md`：逐批 Agent 可执行任务、代码入口与完成条件
- `03_AI_COST_AND_COMPLEXITY_GATES.md`：Token/调用/缓存/降级硬指标
- `04_TEST_AND_LOCAL_VALIDATION.md`：隔离环境、回归与真实验收权限分层
- `05_ACCEPTANCE_AND_HANDOFF.md`：验收门禁和提交报告格式
- `06_AGENT_EXECUTION_PROMPT.md`：整段复制粘贴给 Agent
- `07_WORK_ITEM_TRACKER.csv`：任务和验证结果登记
- `reference/*`：原始审计/验收及旧验证流程，**参考用途，不替代本包执行顺序**
- `scripts/*`：首轮离线基线脚本

> 静态审计报告属于源码行为证据，**不是已在本机复现/全链路验收证明**。开发中如果 HEAD 漂移，须记录新的 SHA 和事实差异；绝不强行 reset 用户工作区。
