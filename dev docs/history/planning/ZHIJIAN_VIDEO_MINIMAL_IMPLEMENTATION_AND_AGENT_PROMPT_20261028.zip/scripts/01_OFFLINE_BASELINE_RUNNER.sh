#!/usr/bin/env bash
# Video-only offline regression in a disposable detached Git worktree.
# No API/Worker startup, no deployment, no DB migration, no production service writes.
set -u
IFS=$'\n\t'

SHA='57df74ab8761223f49acbc9a29a26d0aba2b0b08'
ORIGIN="${1:-.}"
ORIGIN="$(cd "$ORIGIN" && pwd -P)" || exit 2
WORKSPACE="$(mktemp -d /tmp/zhijian-video-audit.XXXXXXXX)" || exit 2
WT="$WORKSPACE/repo"
RESULTS="$WORKSPACE/results"
mkdir -p "$RESULTS"
STATUS="$RESULTS/status.tsv"
printf 'step\tstate\texit_code\n' > "$STATUS"

record() { printf '%s\t%s\t%s\n' "$1" "$2" "$3" >> "$STATUS"; }
run() {
  local label="$1"; shift
  echo "[AUDIT] $label"
  (cd "$WT" && "$@") > "$RESULTS/$label.log" 2>&1
  local code=$?
  if [[ $code -eq 0 ]]; then record "$label" PASS_OFFLINE 0; else record "$label" FAILED_OFFLINE "$code"; fi
  echo "[AUDIT] $label exit=$code"
  return 0
}

{
  echo "frozen_sha=$SHA"
  echo "origin=$ORIGIN"
  echo "workspace=$WORKSPACE"
  echo "date=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "host=$(hostname)"
  echo "git_version=$(git --version)"
  echo "local_head=$(git -C "$ORIGIN" rev-parse HEAD 2>/dev/null || true)"
  echo "python_version=$(python3 --version 2>&1 || true)"
  echo "node_version=$(node --version 2>&1 || true)"
  echo "pnpm_version=$(pnpm --version 2>&1 || true)"
} > "$RESULTS/environment.txt"
(git -C "$ORIGIN" status --short || true) > "$RESULTS/original_git_status.txt" 2>&1

if ! git -C "$ORIGIN" cat-file -e "$SHA^{commit}" 2>/dev/null; then
  echo 'BLOCKED_ENVIRONMENT: 本地克隆尚无冻结 SHA；未尝试 fetch/reset/clean。' | tee "$RESULTS/STOP.txt"
  record source_snapshot BLOCKED_ENVIRONMENT 2
  echo "REPORT_DIR=$RESULTS"
  exit 2
fi
if ! git -C "$ORIGIN" worktree add --detach "$WT" "$SHA" > "$RESULTS/worktree.log" 2>&1; then
  echo 'BLOCKED_ENVIRONMENT: 无法建立隔离工作树，原仓库不做清理。' | tee "$RESULTS/STOP.txt"
  record source_snapshot BLOCKED_ENVIRONMENT 2
  echo "REPORT_DIR=$RESULTS"
  exit 2
fi
record source_snapshot PASS_OFFLINE 0

# All settings below are for test-only runtime. A missing storage config is intentional.
export ENV=development
export ZHIJIAN_DATA_DIR="$WORKSPACE/test-data"
export ZHIJIAN_STORAGE_CONFIG="$WORKSPACE/storage-control.json"
export ZHIJIAN_SECRET_STORE=file
export PYTHONPATH="$WT/backend/src"
export PYTHONDONTWRITEBYTECODE=1
mkdir -p "$ZHIJIAN_DATA_DIR"

PY="$ORIGIN/.venv/bin/python"
if [[ ! -x "$PY" ]]; then
  PY="$ORIGIN/venv/bin/python"
fi
if [[ ! -x "$PY" ]]; then
  echo 'BLOCKED_ENVIRONMENT: 没找到仓库已有 .venv/bin/python 或 venv/bin/python；不安装依赖。' > "$RESULTS/python-blocked.txt"
  record backend_deps BLOCKED_ENVIRONMENT 2
else
  run alembic_heads "$PY" -m alembic -c backend/alembic.ini heads
  run pytest_target "$PY" -m pytest -p no:cacheprovider \
    backend/tests/test_video_notes.py \
    backend/tests/test_video_submission_config.py \
    backend/tests/test_grounded_map.py \
    backend/tests/test_video_semantic_poi.py \
    backend/tests/test_poi_audit_regressions.py \
    backend/tests/test_yunnan_multiregion_travel_golden.py \
    -q --tb=short
  run ruff "$PY" -m ruff check backend/src backend/tests
  run pytest_full "$PY" -m pytest -p no:cacheprovider backend/tests -q --tb=short
  run yunnan_offline "$PY" scripts/check_yunnan_regression.py --output "$RESULTS/yunnan-offline-report.json"
fi

if ! command -v pnpm >/dev/null 2>&1; then
  echo 'BLOCKED_ENVIRONMENT: pnpm 未安装' > "$RESULTS/frontend-blocked.txt"
  record frontend_deps BLOCKED_ENVIRONMENT 2
else
  echo '[AUDIT] frontend offline dependency installation'
  pnpm --dir "$WT/frontend" install --offline --frozen-lockfile \
    > "$RESULTS/frontend_install.log" 2>&1
  install_code=$?
  if [[ "$install_code" -ne 0 ]]; then
    echo 'BLOCKED_ENVIRONMENT: 前端 pnpm 离线缓存可能不完整。' > "$RESULTS/frontend-blocked.txt"
    record frontend_deps BLOCKED_ENVIRONMENT "$install_code"
  else
    record frontend_deps PASS_OFFLINE 0
    run frontend_verify pnpm --dir "$WT/frontend" verify
  fi
fi

cat > "$RESULTS/README.txt" <<SUMMARY
Offline test evidence only; not a production E2E certificate.
Frozen repository SHA: $SHA
Source: $ORIGIN
Isolated worktree: $WT
Result directory: $RESULTS
No intentional external video/model/AMap requests or production writes in this runner.
Tests are repository-owned: review failed logs for possible external dependencies.
To remove the isolated worktree later (only when finished reviewing):
  git -C "$ORIGIN" worktree remove "$WT"
  # then optionally delete "$WORKSPACE" manually
SUMMARY
printf '\n[AUDIT] Complete. REPORT_DIR=%s\n' "$RESULTS"
cat "$STATUS"
