# 04｜本地实施、隔离验证与真实验收的清晰分层

## 0. 正确的工作方式

本地 Agent 是负责**执行小修复和跑测试**，不是重新给出泛化架构方案。优先使用自己的 Mac mini 克隆；但**绝不能直接污染运行服务、SQLite 数据卷、Keychain、生产前端构建目录**。不自动拉起/停止 worker 或重启服务。所有测试使用独立临时根及 Git worktree，冻结 SHA/当前 HEAD 差异先记账。

## 1. 运行现有离线基线（不修改仓库）

工作机具有已有克隆 `/path/to/do-not-litter`。从本包目录执行：

```bash
bash scripts/01_OFFLINE_BASELINE_RUNNER.sh /path/to/do-not-litter
```

它会在 `/tmp/zhijian-video-audit.*/` 建隔离 worktree，使用**冻结审计 SHA**运行旧测试、ruff、云南离线检查、前端测试/Lint/build，并将结果保存在 `results/`；脚本不会自动 fetch、pip install 或重启服务。若克隆没有冻结 SHA，只提示阻塞。该脚本用到了已有后端 venv 和 pnpm 离线缓存；缺依赖时只报环境阻塞。此脚本保留原始版本便于审计可追溯，Agent 应阅读和确认其环境隔离后再执行。

如需要在**最新 HEAD** 开发，则在干净的隔离开发 worktree/feature branch 实施；**不要修改上述归档的基线脚本 SHA 以伪装基线通过**。新增的目标负例先在开发 worktree 中复现，后逐个实施修复。

## 2. 建议 Agent 工作副本模式

```bash
cd /path/to/do-not-litter
git status --short
git rev-parse HEAD
# 只在没有同名路径时执行，路径由 Agent 选择并记录
git worktree add --detach /tmp/zhijian-video-fix-worktree "$(git rev-parse HEAD)"
```

在该副本内使用现有虚拟环境和独立测试配置；**不对运行中目录进行 `pnpm build` 或数据库迁移**。先读取 `backend/pyproject.toml`、`frontend/package.json` 和必要的 `AGENTS.md`，不要在生产环境全局安装包。若 repo 中存在未提交修改且会影响修复，停下说明冲突，不替换用户源文件。

## 3. 分层验证清单

**L0（必跑，无网络/模型）**：可复现负例、正常正例、目标 pytest、Ruff；对 UI/API 受影响处运行对应 Vitest/类型/Lint。所有真实 Provider 都应 Mock；含下载代码也由假媒体 Provider 替身覆盖。V01 测恶意/错误结构化值及合理改写；V02/V03 测 3 轨上限和 srv3；V04/V05 测 Replay 状态；V06/V08 测同名异省和限制合并。

**L1（完成每工作包时）**：一次独立的后端全量 `python -m pytest backend/tests`、`python -m ruff check backend/src backend/tests`、前端 `pnpm --dir frontend verify`（若受影响或 release 前），以及冻结云南 Golden 相关测试/脚本。**不要在每修改一行后重复跑全仓库**。参考原 `02_ORIGINAL_ACCEPTANCE_GATES.md` 中的云南语义范围，并用真实独立证据判断差异；不将单纯字面 TP 说成语义准确率。

**L2（真实上游，只能另行授权）**：B站实时字幕/下载、Mac Qwen ASR/Whisper、外部 LLM、AMap、真实页面 Browser 与 UI；这一步会产生网络、模型额度、磁盘和可能的人工复核成本。执行前必须单独得到视频集合、请求上限、可接受 token 上限及是否允许读/写隔离库的授权。

**L3（生产，只能另行授权）**：停机/重启、更新线上产物、写线上 SQLite、历史回填、迁移、手动 POI 批量确认。当前包默认 **NOT_AUTHORIZED**。

## 4. 最小复现用例卡

| ID | 输入构造 | 通过信号 |
|---|---|---|
| T01 V01 | `segment=门票100元`，错误 `highlight=免费入园` | 不生成高可信免费字段；保留合法来源 |
| T02 V01 | `segment=海蛎煎值得点`，`recommended_items=海蛎煎` | 推荐菜品仍有独立证据；无需新 AI |
| T03 V01 | `A=十月封山`、`B=十月适合`，共享地名上下文 | 不能跨地点/活动误继承 |
| T04 V02 | 首轨成功但 timeline FAIL，第二轨 PASS | 采用第二轨，ASR=0 |
| T05 V02 | 3 轨 FAIL、第 4 轨 PASS | 至多尝试 3 轨，只启动一次 ASR |
| T06 V03 | `srv3` 在 `vtt` 前 | 不将 srv3 传给 VTT 解析器 |
| T07 V04 | 首次与 Replay 同样的非登录 `MediaDownloadError` | 文字笔记保留，终态/错误一致 |
| T08 V05 | 缓存丢失，公开 Replay 入口 | 如被入口正确阻断则记录不可达；不能假定 Bug 已实际触发 |
| T09 V06 | 甲省和乙省同名“东湖”，只确认甲省 | 乙省线路不自动绑定甲省 |
| T10 V08 | 同一条 A→B→C，夏/冬限制不同 | 两份原文和局部约束不丢失 |
| T11 V07 | 同 Transcript/Version 两份 Artifact，Note 固定旧版本 | 若出现路线错绑标记复现；如需迁移停在方案层 |
| T12 总体 | 同视频 Mock 统计所有 stage/ASR/HTTP 调用 | LLM 阶段与调用不增加；字幕 ≤3 |

## 5. 回归验收组合

最小需要覆盖现有：`backend/tests/test_video_notes.py`、`test_grounded_map.py`、`test_video_semantic_poi.py`、`test_poi_audit_regressions.py`、`test_video_submission_config.py`、`test_yunnan_multiregion_travel_golden.py`、`test_ai_request_optimization.py`、`test_job_runtime_optimization.py`、`test_worker.py`，以及关联 `frontend/src/features/video/`、`map/`、`tasks/` 测试。

**输出必须区分**：`PASS_OFFLINE`、`FIXED_VERIFIED`、`NOT_REPRODUCED`、`BLOCKED_ENVIRONMENT`、`NOT_RUN_REAL_E2E`、`PRODUCTION_NOT_VERIFIED`。绝不把代码检查通过写成 Mac 生产验收成功。

## 6. 人工语义金标（真实验收阶段，当前只拟规则）

云南 `BV16Yem6REyX` 为**强制 P0 重点回归样本**：每个核心区域/地点、原词、时节/活动/道路限制、作者路线顺序与地点绑定，需逐句标注原文和 Segment，再裁定 18 字面未匹配、39 额外。其余样本优先厦门探店（菜品/价格/否定）、贵州长列表（多核心召回）、有字幕短视频、无字幕方言/快速语速视频。禁止 71 个参考候选=71 个必需地图 Pin 的错误验收。

测试不足时报告 `GOLD_NOT_READY`，不加 LLM 去凑高分。
