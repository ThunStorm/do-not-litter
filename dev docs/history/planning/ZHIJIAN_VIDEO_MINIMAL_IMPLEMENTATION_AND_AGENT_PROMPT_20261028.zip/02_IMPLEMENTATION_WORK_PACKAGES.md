# 02｜最小修复工作包（按顺序执行，单包止损）

依据 `reference/01_ORIGINAL_CODE_AUDIT.md`。C=源码确认的行为/门禁缺口；R=条件性风险；G=未完成质量验证。修复顺序考虑**事实正确性 > 异常状态一致性 > 可选增强 > 美观**。各包必须保留最小正反例；禁止为凑目标而增加模型调用。

## WP0｜锁定实际代码与离线基线（先做，不修改业务代码）

**输入**：现有 Git 克隆、审计报告、`AGENTS.md`。**产物**：`BASELINE.md`，记录 HEAD、worktree、测试环境、测试实际通过情况、已修复条目与差异。阅读必须按 AGENTS 的精简上下文顺序；先用 `rg -n` 找证据函数，窄范围读取，避免全仓库多次扫描。确认 `scripts/check_yunnan_regression.py` 使用 `--output` 参数；原有云南“71/53/39/18”只是参考候选字面差异，**不是语义金标准确率**。

**本包边界**：允许在隔离 worktree 运行现有只读离线脚本（参见 `04_TEST_AND_LOCAL_VALIDATION.md`）；不安装新大型依赖、不碰线上服务。即使旧全量绿，也不代表 P0 已修复。

**停止条件**：无法建立隔离环境/版本不匹配则 `BLOCKED_ENVIRONMENT`，报告原因，不为测试停机或变更生产配置。

## WP1｜V01 P0：要点字段证据门禁（最高优先级）

**代码入口**：`backend/src/zhijian/services/video_support.py` 的 `_insights_from_candidate`、`materialize_place_insights`；GroundedMap `_canonical_payload` 及 `evidence_trace` 仅在确定相关时修改。

**确定性失败路径**：实体 Quote “门票100元”，模型 `highlights=["免费入园"]`，旧逻辑在字段文本不能被证据支持时直接回退 `ids = ids or list(segment_ids)`，再以 SOURCE_FACT 保存（审计 V01）。

**最小方案**：

1. 在输入物化处对**每条 insight**绑定其自有 `supporting quote + ordered segment_ids`（继续使用已有字段），验证 Quote 来自同一合法 Segment 链（必要时复用现有证据函数，避免新证据基础设施）。**仅证据链存在不等于要点真**：对门票金额/免费与收费、否定与肯定、月份等可机械判断字段校验不冲突；没有确定性支持的摘要不能在高可信 `SOURCE_FACT` 输出。
2. 对不易逐字比对的合理改写，例如“海蛎煎值得点”→“推荐海蛎煎”，在精确原句确立且不存在语义冲突时可保留。对复杂语义不能机器确认时，可保留原作者引文作为低可信观察/原文供用户核查，不虚构 `SOURCE_FACT`，**不新增 LLM 校验调用**。
3. 优先在“候选 → 结构化项”边界修门禁，避免升级所有 Entity/Claim schema；使用已有 `metadata_json` 记录拒绝原因/计数，但不创建新表，不把未验证字段回写旧 Note。
4. 反例：100 元与免费、A 景点事实混入 B 景点、月份无证据、作者不推荐被正向化、同源不同 Segment 错绑。正例：正确菜品、原话推荐、精确季节、同义转述合法。保证正例不大幅掉召回。保留 `quote/id`；语义不确定输出为人工待核或隐藏高可信字段，而非一律丢失原文。

**验收**：错误高可信事实**零条**；正确结构化字段仍可显示；已有 Note/Place/POI API 契约不变；新增 LLM/ASR 请求 `=0`；无需迁移/新依赖。若发现需模型判别才能有质量，**提出备选方案但不要调用**。

## WP2｜V02+V03 P1：用便宜的字幕轨尝试减少昂贵 ASR

**代码入口**：`backend/src/zhijian/resolvers/video/bilibili.py` 的 `first_usable_subtitle`、`youtube.py` 的 `_subtitle_tracks`、`video_pipeline.py` 的 `FETCH_SUBTITLE`。

1. 统一“拉取 → 质量评估 → 接受/继续”选择流程；**首轨成功下载却质量 FAIL 时仍试下一轨**。不同状态 `FETCH_FAILED`、`QUALITY_REJECTED`、`ACCEPTED` 在现有外部调用审计中可区分。保留平台登录阻塞的原行为。
2. **有界尝试**：默认每次最多验证 3 条优先字幕轨（常见人工中文→AI 中文→其他；保证顺序有据），超过上限进入现有 ASR 路径。不能无限列举平台多语言字幕；不增加 LLM 请求。优先使用现有轨道列表/已有质量函数，不引入复杂重评分服务。
3. YouTube `srv3` 是 XML 格式，不送进 VTT 解析器。本批最小实现为**优先选择 VTT、无法识别/没有 VTT 则按现有 ASR 降级**，不为低频 srv3 写全新 XML 字幕兼容层；若现有测试证明 srv3 是关键且有低成本标准解析器，可独立提出后续方案。
4. 强制测试：质量差轨 A + 质量好轨 B→选 B 且 ASR=0；三轨均差→ASR 恰一次；只有 srv3→不误按 VTT 成功；同语言优先 VTT；429/登录、网断均有界退出；不泄露字幕签名 URL。

**成本门禁**：同一视频的**字幕获取 HTTP 请求上限 3**；LLM 调用增量 0，ASR 不得重复；对含可用第二轨视频 ASR 从 1 次下降为 0。测试时记录网络请求数。平台本身如超频应减小上限，不新增大缓存。

## WP3｜V04+V05 P1：截图属于可选增强，Replay 不能破坏核心结果

**代码入口**：`backend/src/zhijian/services/video_pipeline.py` 初次截图步骤和 `_process_video_replay`；若现有工具已可复用，少写辅助函数。

1. V04：创建一个**最小、无外部副作用的截图错误分类**（未登录需人工、普通媒体失败为 PARTIAL、取消中止），初次与 Replay 共同使用。保证已经物化的 Note/POI 不因“可选截图再失败”变成整个视频失败。
2. V05：先依照真实 `replay_options` 入口复现缓存缺失。若入口已完全阻断且后端内部也无可达途径，**只添加防御性测试**；若确实可达，缺素材但有计划必须有显式 `screenshot_error`/PARTIAL 或 `NeedsUser`，不能跳过后标记 COMPLETED。不要人为绕过 Replay 门禁来制造生产缺陷。
3. 必须区分**核心结果完成**与**截图增强失败**，对 UI 保持原有兼容字段；不要改动独立 Job 状态机 API；成功截图与截图跳过、取消、缓存过期的终态应自洽。截图失败重试不可自动重新跑 AI 的 GroundedMap/Note。

**验收**：异常首次/Replay 一致；已成功 Text/POI 不丢；AI 调用增量 0；不重复媒体下载；无线上任务干扰。

## WP4｜V06+V08 P1：路线只绑定确实属于该来源的站点与条件

**代码入口**：`backend/src/zhijian/services/route_guides.py` 的 `list_route_guides`、`extract_routes`，仅必要时触及已有关联测试与 `travel_extensions.py` 的复制门禁。

1. V06：站点匹配不能只用中文名；优先使用同一 NoteVersion、原 `guide.evidence.segment_ids` 与 `Mention.segment_ids_json` 的**语义/区域局部交集**，并检查省/市/内容单元身份。保留“零匹配/多个候选→NEEDS_REVIEW”，不得使用其它段落的已确认 POI 凑满路线。
2. 不改变来源路线“**非导航**”、Unknown 停靠点保持原词、不能复制未逐站确认路线的既有契约。对区域代表点、普通 Place 的边界不要临时创造虚拟地点。
3. V08：仅当 `(mode, ordered stops, road)` 同一且可证明来源相同，才**合并多条来源证据和不同条件**；冬季封路与夏季通行不能互相覆盖，也不可把局部道路限制扩成整个景区限制。若两个对象具有不同顺序/条件语义无法安全合并，保持两条独立来源路线，禁止去重丢弃。
4. V07 版本绑定（R）：只先做“同一 transcript_version 上存在 2 份不同 GroundedMapArtifact”的最小复现。若发现错绑，可优先利用已有可用身份/缓存关联修复；**若必需新 DB 列或迁移，停止在设计建议，不执行迁移**。

**验收**：跨省同名点不得误绑；多条限制均完整保留；云南 D01/D02/D03 等顺序、原文条件回归不变；GET 不触发模型/写入；作者 Route 不改变用户 RouteDraft；AI 调用增量 0。

## 明确延期（不因“顺手”夹带）

- V09 列表分页：尚无性能数据，记入性能基线。若 1,000 Note 环境已触发明确回归，单独开任务，绝不在本次证据修复里破坏 API 全量列表约定。
- V10 重复地名：先加正反 fixture、看实际作者路线误判；本批不改解析器。
- V11 转录保留：只整理数据生命周期与产品契约，不清历史库。
- V12 超大模块：只记维护风险，不启动拆分项目。
- 云南语义金标：独立真实验收，不以字面差异直接要求新增模型。

## 每包完成记录（必须填）

`ID | before_sha | after_sha | failed_test_before | passed_test_after | prod_files_changed | public_contract_delta | added_llm_calls | added_asr_calls | max_subtitle_requests | data_migration | decision | residual_risks`

`decision` 只能是 `FIXED_VERIFIED`、`ALREADY_FIXED_WITH_EVIDENCE`、`NOT_REPRODUCED`、`DEFERRED`、`BLOCKED`。不可写“已生产验证”除非确实跑了对应生产验收并留证。
