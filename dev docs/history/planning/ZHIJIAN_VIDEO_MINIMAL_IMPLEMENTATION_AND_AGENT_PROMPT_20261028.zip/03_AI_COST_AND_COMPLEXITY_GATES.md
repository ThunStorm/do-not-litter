# 03｜AI 用量与复杂度硬门禁（任何 Agent 均必须执行）

## A. 默认不增加真实 AI 用量

- 不增加任何 LLM 阶段：沿用 `CORRECT_TRANSCRIPT`、`EXTRACT_TRAVEL_FACTS`（含现有 GroundMap）、`GENERATE_AI_NOTE` 等，**不增加新的“每地点校验 LLM”“每事实投票”“每路线重判模型”**。
- 不改变现有模型主备策略、Gateway/Cache 的键定义、Context/Mux 连接协议、模型额度设置；无针对性缺陷证据不重写 Prompt。
- WP1 字段证据校验为**确定性、在现有结构化结果上运行**；无法判定则降级待核/原话展示，不重问模型。
- WP2 字幕修复只增加最多 3 次的**低成本字幕 HTTP 尝试上限**（不是新的 AI 请求），优先替代 ASR；所有轨均 FAIL，ASR 仅一次，不对每个轨分别转写。
- WP3/WP4 仅修后处理/结果关联；正常执行、Replay、只读 GET 都不得额外调用 LLM。
- 批量处理历史视频、对全库修复/生成新 Map、动用多个 AI Provider 投票一律禁止。

## B. 对每个工作包测量而不猜测

最少记录以下指标（使用仓库已有 `ExternalCallAudit`、usage/telemetry、模拟 Provider 计数，不引入新的观测服务）：

| 指标 | 对照原则 | 不合格动作 |
|---|---|---|
| `llm_attempts_by_stage` | 同样 fixture、同样配置、相同缓存条件，修后 **≤ 修前** | 查是否新增调用/重复阶段，回退 |
| `asr_invocations` | 无字幕仅 1 次；第二轨可用时为 0；不得因重试双跑 | 修复选择/防重复 |
| `subtitle_http_attempts` | 每视频 **≤3**，记录质量拒绝/HTTP 失败的原因 | 调整策略与上限 |
| `groundmap_cache_hit` | 同输入同版本不因无关前端/UI 变化被清空；保留现有键契约 | 不发布缓存破坏性变动 |
| `prompt_input_chars` | 核心 Prompt 无必要不变；若变动相同 fixture 预期 ≤基线 +2% | 精简变动并复测 |
| `reported_input/output_tokens` | 若做获批的小样真实请求：**新增调用=0**，同例增幅目标 ≤5% | 超限停下确认原因，不自动优化更多阶段 |
| `usage_source` | 严格区分 `reported` / `estimated` / `unknown` | unknown 时不可宣称成本下降 |
| `wall_time_seconds` | 不因默认新增完整 AI 阶段变慢；字幕额外尝试需与节省 ASR 权衡 | 保留降级并说明 |

对含模型随机性的真实输出，只在**相同模型/路由/温度/缓存条件**下比较，记录请求次数而不是以单次 token 差异误判因果。缺少真实 baseline 的时候，用请求构造长度、阶段调用计数和离线缓存命中做**代理指标**，标注 `NOT_MEASURED_REAL_COST`，不能编造节约百分比。

## C. 严禁的“看似智能”方案

- 每个地点额外调用远程模型来审查价格、月份、是否推荐。
- 按地图候选逐个发 LLM 请求以判断相似 POI。
- 每段视频同时调用多个模型投票、重复采集转录或定时从头重跑。
- 在 Note、GroundMap、POI 各自建重复的“事实校验器”，维护三套契约。
- 为了提速删除证据/Segment 或跳过质量门禁。
- 引入 Kafka/Redis/Celery/向量库、统一 Agent DAG、新数据库，仅为这几个 Bug。
- 默认在 CI/离线测试中调用任何真实付费/限额模型、B站下载和高德确认。

## D. 缓存与续跑原则

1. 缓存身份由**实际输入内容、模型、schema/Prompt 版本**决定；修 V01 的输出投影层不得随意全局 bump GroundMap 缓存，触发历史重算。变化只在新运行流程生效；旧数据如有差异，另列迁移方案等待授权。
2. Replay 应尽量复用已有 Transcript/GroundedMap/Note，尤其截图失败仅重试截图增强；不得把“修复某个后处理”变成完整视频重新解析。
3. TTL/中间产物过期时给明确 `NEEDS_USER`/不可续跑指引；**禁止为绕过 TTL 自动重跑全链路**。
4. 保留真正 `repaired` 与 `direct_success` 区分、ExternalCallAudit 请求链及失败原因，不得通过清空 trace 提高表面成功率。

## E. 发布时的成本声明格式

```
同配置/同 fixture：
原版/新版 LLM 请求次数：__ / __
原版/新版 ASR 次数：__ / __
字幕请求次数上限及实测：3 / __
输入输出 Token（reported/estimated/unknown）：__
是否引入额外模型阶段：否（若是，必须阻断）
是否触发已有缓存大面积失效：否（若是，必须阻断）
是否调用真实 Provider：否/经单独授权，记录账单与请求数
```
